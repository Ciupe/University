﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assignment1
{
    public partial class Form1 : Form
    {
        // establishes connection with the database
        SqlConnection conn;

        DataSet ds;

        // we need 2 data adapters, 1 for each table (brings/sends changes from/to the database)
        SqlDataAdapter daInjuries, daPlayers;

        SqlCommandBuilder cbInjuries;

        // bind control to Binding source then bind it to the data source (e.g. ds = the ships data table); control - BS - ds
        BindingSource bsInjuries, bsPlayers;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            // updates data in the database with the changes done in VSCode after running 
            daInjuries.Update(ds, "Injuries");
        }

        // if we write the next function by hand, then we have to go to Form1.Designer.cs and search for   " this.Load += new System.EventHandler(this.Form1_Load);" and manually insert the function name
        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(@"Data Source = DESKTOP-52KHL8B\SQLEXPRESS; Initial Catalog = SportsClubs; " + " Integrated Security = SSPI; ");
            ds = new DataSet();
            daPlayers = new SqlDataAdapter("SELECT * FROM Players", conn);
            daInjuries = new SqlDataAdapter("SELECT * FROM Injuries", conn);
            cbInjuries = new SqlCommandBuilder(daInjuries);
            daPlayers.Fill(ds, "Players");
            daInjuries.Fill(ds, "Injuries");

            // created and added a relation between tables Ships and Pirates; *adds a unique constraint* Parent row = Pid in Players, Children rows = Pid in Injuries
            DataRelation dr = new DataRelation("[FK__Injuries__Pid__77DFC722]", ds.Tables["Players"].Columns["Pid"], ds.Tables["Injuries"].Columns["Pid"]);
            ds.Relations.Add(dr);

            // binding the binding source to the data source
            bsPlayers = new BindingSource();
            bsPlayers.DataSource = ds;
            bsPlayers.DataMember = "Players";

            // we bind pirates using the relation between pirates and ships, so when we select a ship after running the code, only the pirates with that ShipID appear
            bsInjuries = new BindingSource(bsPlayers, "[FK__Injuries__Pid__77DFC722]");


            // doing this below would show us all Injuries whatever player we've chosen after running

            dgvInjuries.DataSource = bsPlayers;
            dgvPlayers.DataSource = bsInjuries;

        }

    }
}
