package model;

import java.io.Serializable;

/**
 * @author radu.
 */
public class BaseEntity<ID> implements Serializable {
    private ID id;

    public ID getId() {
        return this.id;
    }

    public void setId(ID id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "BaseEntity{" +
                "id=" + this.id +
                '}';
    }
}
