package services;

import java.util.concurrent.CompletableFuture;

public interface IRepositoryService {
    CompletableFuture<Void> useInMemory();

    CompletableFuture<Void> useFile();

    CompletableFuture<Void> useXML();

    CompletableFuture<Void> useDatabase();
}
