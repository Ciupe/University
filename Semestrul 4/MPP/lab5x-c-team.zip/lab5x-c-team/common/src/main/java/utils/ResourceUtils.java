package utils;

import java.net.URISyntaxException;
import java.nio.file.Path;

public class ResourceUtils {
    public static String getPath(Class<?> clazz, String resourceName) {
        try {
            return Path.of(clazz.getResource(resourceName).toURI()).toString();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
