package services;

import exceptions.ControllerException;
import model.Client;
import model.Rental;
import model.validators.ValidatorException;
import org.springframework.beans.factory.annotation.Autowired;
import repository.Repository;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ClientService implements IClientService{
    @Autowired
    private Repository<Long, Client> clients;
    @Autowired
    private RentalService rentalService;

    /**
     * Returns all the clients.
     *
     * @return the set of clients
     */
    public Set<Client> getClients() {
        Iterable<Client> clients = this.clients.findAll();
        return StreamSupport.stream(clients.spliterator(), false).collect(Collectors.toSet());
    }

    /**
     * Returns the client with a given id.
     *
     * @param id the id of the client
     * @return the client
     */
    public Client getClient(Long id) {
        return this.clients.findOne(id)
                .orElseThrow(() -> new ControllerException(String.format("Client id not found: %d", id)));
    }

    /**
     * Add client to the client repository
     *
     * @param client
     * @throws ValidatorException
     */
    public void addClient(Client client) throws ValidatorException {
        this.clients.save(client)
                .ifPresent(x -> {
                    throw new ControllerException(String.format("Client id already exists: %d", client.getId()));
                });
    }

    /**
     * Delete a client from the client repository.
     *
     * @param clientId the client's id to delete.
     */
    public void deleteClient(Long clientId) {
        Set<Rental> rentalsWithClientId = this.rentalService.filterRentalsByClientId(clientId);
        rentalsWithClientId.forEach(rental -> {
            try {
                this.rentalService.deleteRental(rental.getId());
            } catch (Exception e) {
                throw new ControllerException(e.getMessage());
            }
        });

        this.clients.delete(clientId)
                .orElseThrow(() -> new ControllerException(String.format("Client id not found: %d", clientId)));
    }

    /**
     * Updates an existent client.
     *
     * @param client
     * @throws ValidatorException
     */
    public void updateClient(Client client) throws ValidatorException {
        this.clients.update(client)
                .orElseThrow(() -> new ControllerException(String.format("(Update) Client id not found: %d", client.getId())));
    }

    /**
     * Returns all clients with a matching or a partial matching name.
     * @param name the client name
     * @return the set of clients with a matching or a partially matching name.
     */
    public Set<Client> filterClientByName(String name) {
        return StreamSupport.stream(this.clients.findAll().spliterator(), false)
                .filter(client -> client.getName().contains(name))
                .collect(Collectors.toSet());
    }
}