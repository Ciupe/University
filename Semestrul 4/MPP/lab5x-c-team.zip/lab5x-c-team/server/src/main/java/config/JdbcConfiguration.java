package config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.postgresql.Driver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
public class JdbcConfiguration {
    @Bean
    JdbcOperations jdbcOperations() {
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(this.getDataSource());
        return jdbcTemplate;
    }

    @Bean
    DataSource getDataSource() {
        BasicDataSource basicDataSource = new BasicDataSource();
        basicDataSource.setDriverClassName(Driver.class.getName());
        basicDataSource.setUsername("iliujrcjjhsxuc");
        basicDataSource.setPassword("56189b18c75c647d4a06360a9d1864e7659d2f900fb9af8c5762473898f30c02");
        basicDataSource.setUrl("jdbc:postgresql://ec2-54-73-68-39.eu-west-1.compute.amazonaws.com/do3920l2m485l");
        basicDataSource.setInitialSize(2);
        return basicDataSource;
    }
}
