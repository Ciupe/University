package repository.database;

import model.BaseEntity;
import model.validators.Validator;
import org.springframework.jdbc.core.JdbcOperations;
import repository.Repository;

public abstract class DatabaseRepository<ID, T extends BaseEntity<ID>> implements Repository<ID, T> {
    protected final Validator<T> validator;
    protected final JdbcOperations jdbcOperations;

    public DatabaseRepository(Validator<T> validator, JdbcOperations jdbcOperations) {
        this.validator = validator;
        this.jdbcOperations = jdbcOperations;
    }
}
