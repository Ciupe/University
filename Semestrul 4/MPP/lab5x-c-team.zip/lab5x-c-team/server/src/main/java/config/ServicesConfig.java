package config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import services.*;

@Configuration
public class ServicesConfig {
    @Bean
    IRentalService rentalService() {
        return new RentalService();
    }

    @Bean
    IClientService clientService() {
        return new ClientService();
    }

    @Bean
    IWebDomainService webDomainService() {
        return new WebDomainService();
    }
}