package repository.database;

import model.Client;
import model.validators.ClientValidator;
import model.validators.ValidatorException;
import org.springframework.jdbc.core.JdbcOperations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ClientDatabaseRepository extends DatabaseRepository<Long, Client> {
    public ClientDatabaseRepository(ClientValidator validator, JdbcOperations jdbcOperations) {
        super(validator, jdbcOperations);
    }

    @Override
    public Optional<Client> findOne(Long id) {
        String sql = "select * from \"Client\" where id = " + id;

        List<Client> clients = jdbcOperations.query(sql,
                (resultSet, rowNum) -> this.getClientFromResultSet(resultSet));

        if (clients.isEmpty())
            return Optional.empty();

        return Optional.of(clients.get(0));
    }

    @Override
    public Iterable<Client> findAll() {
        String sql = "select * from \"Client\"";

        return jdbcOperations.query(sql,
                (resultSet, rowNum) -> this.getClientFromResultSet(resultSet));
    }

    private Client getClientFromResultSet(ResultSet resultSet) throws SQLException {
        Long clientId = (long) resultSet.getInt("id");
        String clientName = resultSet.getString("name");
        boolean isBusiness = resultSet.getBoolean("isBusiness");

        Client client = new Client(clientName, isBusiness);
        client.setId(clientId);

        return client;
    }

    @Override
    public Optional<Client> save(Client client) throws ValidatorException {
        validator.validate(client);
        Optional<Client> existingClient = this.findOne(client.getId());

        String sql = "insert into \"Client\" (id, name, \"isBusiness\") values(?, ?, ?)";
        jdbcOperations.update(sql, client.getId(), client.getName(), client.isBusiness());

        return existingClient;
    }

    @Override
    public Optional<Client> delete(Long id) {
        Optional<Client> clientToDelete = this.findOne(id);

        String sql = "delete from \"Client\" where id = ?";
        jdbcOperations.update(sql, id);

        return clientToDelete;
    }

    @Override
    public Optional<Client> update(Client newClient) throws ValidatorException {
        validator.validate(newClient);
        Optional<Client> oldClient = this.findOne(newClient.getId());

        String sql = "update \"Client\" set name = ?, \"isBusiness\" = ? where id = ?";
        jdbcOperations.update(sql, newClient.getName(), newClient.isBusiness(), newClient.getId());

        return oldClient;
    }
}
