package services;

import exceptions.ControllerException;
import model.Rental;
import model.WebDomain;
import model.validators.ValidatorException;
import org.springframework.beans.factory.annotation.Autowired;
import repository.Repository;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class WebDomainService implements IWebDomainService{
    @Autowired
    private Repository<Long, WebDomain> webDomains;
    @Autowired
    private RentalService rentalService;

    /**
     * Returns all the domains.
     *
     * @return the set of domains
     */
    public Set<WebDomain> getDomains() {
        Iterable<WebDomain> domains = this.webDomains.findAll();
        return StreamSupport.stream(domains.spliterator(), false).collect(Collectors.toSet());
    }

    /**
     * Returns the domain with a given id.
     *
     * @param id the id of the domain
     * @return the domain
     */
    public WebDomain getDomain(Long id) {
        return this.webDomains.findOne(id)
                .orElseThrow(() -> new ControllerException(String.format("Domain id not found: %d", id)));
    }

    /**
     * Add domain to the domain repository
     *
     * @param webDomain
     * @throws ValidatorException
     */
    public void addDomain(WebDomain webDomain) throws ValidatorException {
        this.webDomains.save(webDomain)
                .ifPresent(x -> {
                    throw new ControllerException(String.format("Domain id already exists: %d", webDomain.getId()));
                });
    }

    /**
     * Delete a domain from the domain repository.
     *
     * @param domainId the domain's id to delete.
     */
    public void deleteDomain(Long domainId) {
        Set<Rental> rentalsWithDomainId = this.rentalService.filterRentalsByDomainId(domainId);
        rentalsWithDomainId.forEach(rental -> {
            try {
                this.rentalService.deleteRental(rental.getId());
            } catch (Exception e) {
                throw new ControllerException(e.getMessage());
            }
        });

        this.webDomains.delete(domainId)
                .orElseThrow(() -> new ControllerException(String.format("Domain id not found: %d", domainId)));
    }

    /**
     * Updates an existent domain.
     *
     * @param webDomain
     * @throws ValidatorException
     */
    public void updateDomain(WebDomain webDomain) throws ValidatorException {
        this.webDomains.update(webDomain)
                .orElseThrow(() -> new ControllerException(String.format("(Update) Domain id not found: %d", webDomain.getId())));
    }

    /**
     * Returns all domains with a matching or a partially matching name.
     * @param name the domain name
     * @return the set of domains with a matching or a partially matching name.
     */
    public Set<WebDomain> filterDomainByName(String name) {
        return StreamSupport.stream(this.webDomains.findAll().spliterator(), false)
                .filter(domain -> domain.getName().contains(name))
                .collect(Collectors.toSet());
    }
}