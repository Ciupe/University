package repository.database;

import model.WebDomain;
import model.validators.ValidatorException;
import model.validators.WebDomainValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class WebDomainDatabaseRepository extends DatabaseRepository<Long, WebDomain> {
    public WebDomainDatabaseRepository(WebDomainValidator validator, JdbcOperations jdbcOperations) {
        super(validator, jdbcOperations);
    }

    @Autowired
    private JdbcOperations jdbcOperations;

    @Override
    public Optional<WebDomain> findOne(Long id) {
        String sql = "select * from \"WebDomain\" where id = " + id;

        List<WebDomain> webDomains =  jdbcOperations.query(sql,
                (resultSet, rowNum) -> this.getWebDomainFromResultSet(resultSet));

        if (webDomains.isEmpty())
            return Optional.empty();

        return Optional.of(webDomains.get(0));
    }

    @Override
    public Iterable<WebDomain> findAll() {
        String sql = "select * from \"WebDomain\"";

        return jdbcOperations.query(sql,
                (resultSet, rowNum) -> this.getWebDomainFromResultSet(resultSet));
    }

    private WebDomain getWebDomainFromResultSet(ResultSet resultSet) throws SQLException {
        Long webDomainId = (long) resultSet.getInt("id");
        String webDomainName = resultSet.getString("name");
        Integer webDomainPrice = resultSet.getInt("price");

        WebDomain webDomain = new WebDomain(webDomainName, webDomainPrice);
        webDomain.setId(webDomainId);

        return webDomain;
    }

    @Override
    public Optional<WebDomain> save(WebDomain webDomain) throws ValidatorException {
        validator.validate(webDomain);
        Optional<WebDomain> existingDomain = this.findOne(webDomain.getId());

        String sql = "insert into \"WebDomain\" (id, name, price) values(?, ? , ?)";
        jdbcOperations.update(sql, webDomain.getId(), webDomain.getName(), webDomain.getPrice());

        return existingDomain;
    }

    @Override
    public Optional<WebDomain> delete(Long id) {
        Optional<WebDomain> webDomainToDelete = this.findOne(id);

        String sql = "delete from \"WebDomain\" where id = ?";
        jdbcOperations.update(sql, id);

        return webDomainToDelete;
    }

    @Override
    public Optional<WebDomain> update(WebDomain newWebDomain) throws ValidatorException {
        validator.validate(newWebDomain);
        Optional<WebDomain> oldWebDomain = this.findOne(newWebDomain.getId());

        String sql = "update \"WebDomain\" set name = ?, price = ? where id = ?";
        jdbcOperations.update(sql, newWebDomain.getName(), newWebDomain.getPrice(), newWebDomain.getId());

        return oldWebDomain;
    }
}
