package repository.database;

import model.Rental;
import model.validators.RentalValidator;
import model.validators.ValidatorException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class RentalDatabaseRepository extends DatabaseRepository<Long, Rental> {
    public RentalDatabaseRepository(RentalValidator validator, JdbcOperations jdbcOperations) {
        super(validator, jdbcOperations);
    }

    @Autowired
    private JdbcOperations jdbcOperations;

    @Override
    public Optional<Rental> findOne(Long id) {
        String sql = "select * from \"Rental\" where id = " + id;

        List<Rental> rentals = jdbcOperations.query(sql,
                (resultSet, rowNum) -> this.getRentalFromResultSet(resultSet));

        if (rentals.isEmpty())
            return Optional.empty();

        return Optional.of(rentals.get(0));
    }

    @Override
    public Iterable<Rental> findAll() {
        String sql = "select * from \"Rental\"";

        return jdbcOperations.query(sql,
                (resultSet, rowNum) -> this.getRentalFromResultSet(resultSet));
    }

    private Rental getRentalFromResultSet(ResultSet resultSet) throws SQLException {
        Long rentalId = (long) resultSet.getInt("id");
        Long clientId = (long) resultSet.getInt("clientId");
        Long webDomainId = (long) resultSet.getInt("webDomainId");
        String rentalStartDate = resultSet.getString("startDate");
        Integer rentalDuration = resultSet.getInt("duration");

        Rental rental = new Rental(clientId, webDomainId, rentalStartDate, rentalDuration);
        rental.setId(rentalId);

        return rental;
    }

    @Override
    public Optional<Rental> save(Rental rental) throws ValidatorException {
        validator.validate(rental);
        Optional<Rental> existingRental = this.findOne(rental.getId());

        String sql = "insert into \"Rental\" (\"id\", \"clientId\", \"webDomainId\", \"startDate\", \"duration\") " +
                "values(?, ?, ?, ?, ?)";
        jdbcOperations.update(sql, rental.getId(), rental.getClientId(), rental.getDomainId(),
                rental.getStartDate(), rental.getDuration());

        return existingRental;
    }

    @Override
    public Optional<Rental> delete(Long id) {
        Optional<Rental> rentalToDelete = this.findOne(id);

        String sql = "delete from \"Rental\" where id = ?";
        jdbcOperations.update(sql, id);

        return rentalToDelete;
    }

    @Override
    public Optional<Rental> update(Rental newRental) throws ValidatorException {
        validator.validate(newRental);
        Optional<Rental> oldRental = this.findOne(newRental.getId());

        String sql = "update \"Rental\" set \"clientId\" = ?, \"webDomainId\" = ?," +
                " \"startDate\" = ?, duration = ? where id = ?";
        jdbcOperations.update(sql, newRental.getClientId(), newRental.getDomainId(),
                newRental.getStartDate(), newRental.getDuration(), newRental.getId());

        return oldRental;
    }
}
