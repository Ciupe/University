package config;

import model.Client;
import model.Rental;
import model.WebDomain;
import model.validators.ClientValidator;
import model.validators.RentalValidator;
import model.validators.WebDomainValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.JdbcOperations;
import repository.database.ClientDatabaseRepository;
import repository.database.DatabaseRepository;
import repository.database.RentalDatabaseRepository;
import repository.database.WebDomainDatabaseRepository;

@Configuration
@Import(JdbcConfiguration.class)
public class RepositoriesConfiguration {
    @Autowired
    private JdbcOperations jdbcOperations;

    @Bean
    DatabaseRepository<Long, Client> clientDatabaseRepository() {
        return new ClientDatabaseRepository(new ClientValidator(), jdbcOperations);
    }

    @Bean
    DatabaseRepository<Long, WebDomain> webDomainDatabaseRepository() {
        return new WebDomainDatabaseRepository(new WebDomainValidator(),jdbcOperations);
    }

    @Bean
    DatabaseRepository<Long, Rental> rentalDatabaseRepository(){
        return new RentalDatabaseRepository(new RentalValidator(), jdbcOperations);
    }
}
