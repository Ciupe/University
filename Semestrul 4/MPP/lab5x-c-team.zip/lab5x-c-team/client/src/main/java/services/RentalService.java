package services;

import model.Client;
import model.Rental;
import model.WebDomain;
import model.validators.ValidatorException;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

public class RentalService implements IRentalService {
    @Autowired
    private IRentalService rentalService;

    /**
     * Requests to server to get all the rentals.
     *
     * @return the possible set of rentals
     */
    public Set<Rental> getRentals() {
        return this.rentalService.getRentals();
    }

    /**
     * Requests to server the rental with a given id.
     *
     * @param id the id of the rental
     * @return the possible rental
     */
    public Rental getRental(Long id) {
        return this.rentalService.getRental(id);
    }

    /**
     * Requests to server to add new rental to the rental repository.
     *
     * @param rental new rental
     */
    public void addRental(Rental rental) { this.rentalService.addRental(rental); }


    /**
     * Requests to server to delete a rental from the rental repository.
     *
     * @param rentalId the rental's id to delete
     */
    public void deleteRental(Long rentalId) {
        this.rentalService.deleteRental(rentalId);
    }

    /**
     * Requests to server to update an existent rental.
     *
     * @param rental the rental to be updated
     * @throws ValidatorException if new rental is not valid
     */
    public void updateRental(Rental rental) throws ValidatorException {
        this.rentalService.updateRental(rental);
    }

    /**
     * Requests to server to get all rentals for a given client id.
     * @param id the client's id
     * @return the possible set of rentals of the matching client id.
     */
    public Set<Rental> filterRentalsByClientId(Long id) {
        return this.rentalService.filterRentalsByClientId(id);
    }

    /**
     * Requests to server to get all rentals for a given web domain id.
     * @param id the web domain's id.
     * @return the possible set of rentals of the given web domain.
     */
    public Set<Rental> filterRentalsByDomainId(Long id) {
        return this.rentalService.filterRentalsByDomainId(id);
    }

    /**
     * Requests to server to get all rentals for a given client name.
     * @param name the client's name
     * @return the possible set of rentals of the matching client name.
     */
    public Set<Rental> filterRentalsByClientName(String name) {
        return this.rentalService.filterRentalsByClientName(name);
    }

    /**
     * Requests to server to get all rentals for a given domain name.
     * @param name the domain's name
     * @return the possible set of rentals a the matching domain name.
     */
    public Set<Rental> filterRentalsByDomainName(String name) {
        return this.rentalService.filterRentalsByDomainName(name);
    }

    /**
     * Requests to server to get the clients with most rentals.
     * @return the possible set of clients with most rentals
     */
    public Set<Client> getMostRentingClients() {
        return this.rentalService.getMostRentingClients();
    }

    /**
     * Requests to server to get the most rented domains.
     * @return the possible set of the most rented domains.
     */
    public Set<WebDomain> getMostRentedDomains() {
        return this.rentalService.getMostRentedDomains();
    }

    /**
     * Requests to server to get the years with the most rentals.
     * @return the possible set of years.
     */
    public Set<String> getMostRentedYears() {
        return this.rentalService.getMostRentedYears();
    }

    /**
     * Requests to server to get the most rented TLD.
     * @return the possible set of most rented TLD
     */
    public Set<String> getMostCommonTld() {
        return this.rentalService.getMostCommonTld();
    }
}
