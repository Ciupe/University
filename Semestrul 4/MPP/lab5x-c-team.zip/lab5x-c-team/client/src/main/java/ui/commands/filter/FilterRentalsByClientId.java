package ui.commands.filter;

import exceptions.CommandException;
import model.Client;
import model.Rental;
import model.WebDomain;
import org.springframework.context.ApplicationContext;
import services.ClientService;
import services.RentalService;
import services.WebDomainService;
import ui.annotations.Command;
import ui.commands.BaseCommand;

import java.util.Comparator;
import java.util.Deque;
import java.util.Optional;

@Command(
        key = "clientId",
        description = "Print rentals with a client id.",
        usage = "rentals filter clientId <client id>",
        group = "rentals.filter"
)
public class FilterRentalsByClientId extends BaseCommand {
    private RentalService rentalService;
    private ClientService clientService;
    private WebDomainService webDomainService;

    public FilterRentalsByClientId(String key, String description) {
        super(key, description);
    }

    @Override
    public void init(ApplicationContext context) {
        this.rentalService = context.getBean(RentalService.class);
        this.clientService = context.getBean(ClientService.class);
        this.webDomainService = context.getBean(WebDomainService.class);
    }

    @Override
    public void execute(Deque<String> args) {
        Optional.of(args.size())
                .filter(s -> s == 1)
                .orElseThrow(() -> new CommandException(String.format("Invalid number of parameters. Expected %d found %d", 1, args.size())));

        Long id = Long.parseLong(args.pop());
        this.rentalService.filterRentalsByClientId(id)
                .stream()
                .sorted(Comparator.comparing(Rental::getId))
                .forEach(rental -> {
                    Client client = this.clientService.getClient(rental.getClientId());
                    WebDomain domain = this.webDomainService.getDomain(rental.getDomainId());

                    String rentalString = String.format("Rental { Client='%s', Domain='%s', Start Date=%s, Duration=%d }",
                            client.getName(),
                            domain.getName(),
                            rental.getStartDate(),
                            rental.getDuration()
                    );

                    System.out.printf("%d. %s%n", rental.getId(), rentalString);
                });
    }
}
