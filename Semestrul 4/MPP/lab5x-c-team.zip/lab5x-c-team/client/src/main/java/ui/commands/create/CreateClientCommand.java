package ui.commands.create;

import exceptions.CommandException;
import model.Client;
import org.springframework.context.ApplicationContext;
import services.ClientService;
import ui.annotations.Command;
import ui.commands.BaseCommand;

import java.util.Deque;
import java.util.Optional;

@Command(
        key = "create",
        description = "Create a new client.",
        usage = "clients create <id> <name> <is_business(yes/no)>",
        group = "clients"
)
public class CreateClientCommand extends BaseCommand {
    private ClientService clientService;

    public CreateClientCommand(String key, String description) {
        super(key, description);
    }

    @Override
    public void init(ApplicationContext context) {
        this.clientService = context.getBean(ClientService.class);
    }

    @Override
    public void execute(Deque<String> args) {
        Optional.of(args.size())
                .filter(s -> s == 3)
                .orElseThrow(() -> new CommandException(String.format("Invalid number of parameters. Expected %d found %d", 3, args.size())));

        Client client = new Client();
        client.setId(Long.parseLong(args.pop()));
        client.setName(args.pop());
        client.setIsBusiness(args.pop().equalsIgnoreCase("YES"));

        this.clientService.addClient(client);
    }
}