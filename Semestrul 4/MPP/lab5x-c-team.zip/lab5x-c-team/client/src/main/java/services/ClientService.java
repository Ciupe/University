package services;

import model.Client;
import model.validators.ValidatorException;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Set;

public class ClientService implements IClientService {
    @Autowired
    private IClientService clientService;

    /**
     * Returns all the clients.
     *
     * @return the set of clients
     */
    public Set<Client> getClients() {
        return this.clientService.getClients();
    }

    /**
     * Returns the client with a given id.
     *
     * @param id the id of the client
     * @return the client
     */
    public Client getClient(Long id) {
        return this.clientService.getClient(id);
    }

    /**
     * Add client to the client repository
     *
     * @param client
     * @throws ValidatorException
     */
    public void addClient(Client client) throws ValidatorException {
        this.clientService.addClient(client);
    }

    /**
     * Delete a client from the client repository.
     *
     * @param clientId the client's id to delete.
     */
    public void deleteClient(Long clientId) {
        this.clientService.deleteClient(clientId);
    }

    /**
     * Updates an existent client.
     *
     * @param client
     * @throws ValidatorException
     */
    public void updateClient(Client client) throws ValidatorException {
       this.clientService.updateClient(client);
    }

    /**
     * Returns all clients with a matching or a partial matching name.
     * @param name the client name
     * @return the set of clients with a matching or a partially matching name.
     */
    public Set<Client> filterClientByName(String name) {
        return this.clientService.filterClientByName(name);
    }
}