package ui.commands.print;

import model.WebDomain;
import org.springframework.context.ApplicationContext;
import services.WebDomainService;
import ui.annotations.Command;
import ui.commands.BaseCommand;

import java.util.Comparator;
import java.util.Deque;

@Command(
        key = "print",
        description = "Print all the domains.",
        group = "domains"
)
public class PrintDomainsCommand extends BaseCommand {
    private WebDomainService webDomainService;
    private Object ExecutionException;
    private Object InterruptedException;

    public PrintDomainsCommand(String key, String description) {
        super(key, description);
    }

    @Override
    public void init(ApplicationContext context) {
        this.webDomainService = context.getBean(WebDomainService.class);
    }

    @Override
    public void execute(Deque<String> args) {
        this.webDomainService.getDomains().stream()
                .sorted(Comparator.comparing(WebDomain::getId))
                .forEach(domain -> System.out.printf("%d. %s%n", domain.getId(), domain.toString()));
    }
}
