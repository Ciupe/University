package config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiProxyFactoryBean;
import services.*;
import ui.services.CommandService;


@Configuration
public class ClientConfig {
    @Bean
    RmiProxyFactoryBean rmiClientProxyFactoryBean() {
        RmiProxyFactoryBean rmiProxyFactoryBean = new RmiProxyFactoryBean();
        rmiProxyFactoryBean.setServiceUrl("rmi://localhost:1099/ClientService");
        rmiProxyFactoryBean.setServiceInterface(IClientService.class);
        return rmiProxyFactoryBean;
    }

    @Bean
    RmiProxyFactoryBean rmiWebDomainProxyFactoryBean() {
        RmiProxyFactoryBean rmiProxyFactoryBean = new RmiProxyFactoryBean();
        rmiProxyFactoryBean.setServiceUrl("rmi://localhost:1099/WebDomainService");
        rmiProxyFactoryBean.setServiceInterface(IWebDomainService.class);
        return rmiProxyFactoryBean;
    }

    @Bean
    RmiProxyFactoryBean rmiRentalProxyFactoryBean() {
        RmiProxyFactoryBean rmiProxyFactoryBean = new RmiProxyFactoryBean();
        rmiProxyFactoryBean.setServiceUrl("rmi://localhost:1099/RentalService");
        rmiProxyFactoryBean.setServiceInterface(IRentalService.class);
        return rmiProxyFactoryBean;
    }

    @Bean
    IClientService clientService() {
        return new ClientService();
    }

    @Bean
    IWebDomainService webDomainService() {
        return new WebDomainService();
    }

    @Bean
    IRentalService rentalService() {
        return new RentalService();
    }

    @Bean
    CommandService commandService() {
        return new CommandService();
    }
}