package ui.commands.print;

import model.Client;
import model.Rental;
import model.WebDomain;
import org.springframework.context.ApplicationContext;
import services.ClientService;
import services.RentalService;
import services.WebDomainService;
import ui.annotations.Command;
import ui.commands.BaseCommand;

import java.util.Comparator;
import java.util.Deque;

@Command(
        key = "print",
        description = "Print all the rentals.",
        group = "rentals"
)
public class PrintRentalsCommand extends BaseCommand {
    private RentalService rentalService;
    private ClientService clientService;
    private WebDomainService webDomainService;

    public PrintRentalsCommand(String key, String description) {
        super(key, description);
    }

    @Override
    public void init(ApplicationContext context) {
        this.rentalService = context.getBean(RentalService.class);
        this.clientService = context.getBean(ClientService.class);
        this.webDomainService = context.getBean(WebDomainService.class);
    }

    @Override
    public void execute(Deque<String> args)  {
        this.rentalService.getRentals().stream()
                .sorted(Comparator.comparing(Rental::getId))
                .forEach(rental -> {
                    Client client = this.clientService.getClient(rental.getClientId());
                    WebDomain domain = this.webDomainService.getDomain(rental.getDomainId());

                    String rentalString = String.format("Rental { Client='%s', Domain='%s', Start Date=%s, Duration=%d }",
                            client.getName(),
                            domain.getName(),
                            rental.getStartDate(),
                            rental.getDuration()
                    );

                    System.out.printf("%d. %s%n", rental.getId(), rentalString);
                });
    }
}
