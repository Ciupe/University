package ui.commands.create;

import exceptions.CommandException;
import model.WebDomain;
import org.springframework.context.ApplicationContext;
import services.WebDomainService;
import ui.annotations.Command;
import ui.commands.BaseCommand;

import java.util.Deque;
import java.util.Optional;

@Command(
        key = "create",
        description = "Create a new domain.",
        usage = "domains create <id> <name> <price>",
        group = "domains"
)
public class CreateDomainCommand extends BaseCommand {
    private WebDomainService webDomainService;

    public CreateDomainCommand(String key, String description) {
        super(key, description);
    }

    @Override
    public void init(ApplicationContext context) {
        this.webDomainService = context.getBean(WebDomainService.class);
    }

    @Override
    public void execute(Deque<String> args) {
        Optional.of(args.size())
                .filter(s -> s == 3)
                .orElseThrow(() -> new CommandException(String.format("Invalid number of parameters. Expected %d found %d", 3, args.size())));

        WebDomain webDomain = new WebDomain();
        webDomain.setId(Long.parseLong(args.pop()));
        webDomain.setName(args.pop());
        webDomain.setPrice(Integer.parseInt(args.pop()));

        this.webDomainService.addDomain(webDomain);
    }
}
