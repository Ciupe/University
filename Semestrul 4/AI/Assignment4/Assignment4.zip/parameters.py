runs = 30
iterations_per_run = 40
population_size = 20
individual_size = 10
crossover_probability = 0.8
mutation_probability = 0.04
